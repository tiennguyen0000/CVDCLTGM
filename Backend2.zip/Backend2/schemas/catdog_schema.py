from pydantic import BaseModel
from typing import Optional
from PIL import Image
import base64
from io import BytesIO

class ImageResponse(BaseModel):
    image_data: str  # Chuỗi base64 chứa dữ liệu ảnh

    @classmethod
    def from_image(cls, image: Image.Image, format: str = "JPEG") -> "ImageResponse":
        buffered = BytesIO()
        image.save(buffered, format=format)
        img_str = base64.b64encode(buffered.getvalue()).decode("utf-8")
        return cls(image_data=img_str)



