import sys 
from pathlib import Path
sys.path.append(str(Path(__file__).parent))

from fastapi import FastAPI, Request
from middleware import LogMiddleware, setup_cors
from routes.base import router
from models.catdog_predictor import Predictor
import json

app = FastAPI()

app.add_middleware(LogMiddleware)
setup_cors(app)
app.include_router(router)

# Initialize the predictor



