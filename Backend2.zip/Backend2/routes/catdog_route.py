import sys
from pathlib import Path
sys.path.append(str(Path.cwd()))
from fastapi import APIRouter
from schemas.catdog_schema import ImageResponse
from diffusers import AutoPipelineForText2Image
import torch

pipeline = AutoPipelineForText2Image.from_pretrained(
    "stabilityai/stable-diffusion-xl-base-1.0", torch_dtype=torch.float16, variant="fp16").to("cuda")
generator = torch.Generator("cuda").manual_seed(31)

router = APIRouter()


@router.post("/gen")
async def predict(txt: str):
    response = await pipeline(txt, generator=generator)
    image = response.images[0]

    return {"txt": txt}



